package com.mymavenspringapp.dao;

import java.sql.PreparedStatement;




public class UserDao {

     public int saveUser(String userName, String firstName, String lastName, String gender){
          try{
              String query = "insert into user_info(user_name, first_name, last_name, gender) values(?,?,?,?)";
               PreparedStatement ps = ConnectionProvider.getConnection().prepareStatement(query);
              ps.setString(1, userName);
              ps.setString(2, firstName);
              ps.setString(3, lastName);
              ps.setString(4, gender);
              int result = ps.executeUpdate();
              return result;
          }catch(Exception e){
               System.out.println("Error occured while saving user "+userName);
          }
          return 0;
     }
}
