package com.mymavenspringapp.dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


public class ConnectionProvider {

     private static Connection con = getNewConnection();

     private static Connection getNewConnection() {
          Connection newCon = null;
          Properties prop = new Properties();
          try {
            /*FileInputStream fis = new FileInputStream("C:\\Users\\chanchal.kumar\\workspace\\practicespringproj\\resources\\db.properties");*/
               ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
               InputStream fis = classLoader.getResourceAsStream("/db.properties");
            prop.load(fis);
            System.out.println(prop.getProperty("db_driver_class"));
          } catch (Exception e) {
               System.out.println("Some error occured while loading properites file " + e.getMessage());
          }
          
          try {
               Class.forName(prop.getProperty("db_driver_class"));
               System.out.println("Connecting to database...");
               newCon = DriverManager.getConnection(prop.getProperty("db_url"), prop.getProperty("db_username"),
                         prop.getProperty("db_password"));
          } catch (Exception e) {
               e.printStackTrace();
          }
          
          return newCon;
     }

     public static Connection getConnection() {
          return con;
     }
     
}
