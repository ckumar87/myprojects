package com.mymavenspringapp.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mymavenspringapp.dao.UserDao;


@Controller
public class HomeController {
     
     @RequestMapping(value="/", method=RequestMethod.GET)
     public String home(){
          System.out.println("Entered into home");
          
          System.out.println("Returing from home controller");
          return "home";
     }
     
     @RequestMapping(value="saveUser", method=RequestMethod.POST)
     public String saveUser(HttpServletRequest req){
          String userName = req.getParameter("userName");
          String firstName = req.getParameter("firstName");
          String lastName = req.getParameter("lastName");
          String gender = req.getParameter("gender");
          UserDao userDao = new UserDao();
          
          int i = userDao.saveUser(userName, firstName, lastName, gender);
          if(i>0){
               System.out.println("save successfully");
          }else{
               System.out.println("Not saved");
          }
          return "home";
     }
}
